document.addEventListener('DOMContentLoaded', function() {
    // Add confirmation to all delete buttons/links
    const deleteButtons = document.querySelectorAll('.delete-btn, a[href*="delete"]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            const confirmation = confirm('Are you sure you want to delete this item? This action cannot be undone.');
            if (!confirmation) {
                event.preventDefault();
            }
        });
    });
});