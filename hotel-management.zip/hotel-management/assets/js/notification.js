/**
 * Admin Notification Polling Script
 *
 * This script periodically checks for new notifications (new orders or cancellation requests)
 * from the server. If a new notification is detected, it plays a sound to alert the admin.
 */
document.addEventListener('DOMContentLoaded', function () {

    // --- Configuration ---
    const checkInterval = 15000; // Time in milliseconds between checks (e.g., 15000 = 15 seconds)
    const notificationApiUrl = '/api/check_notifications.php'; // The server endpoint to poll
    const soundFileUrl = '/assets/audio/notification.mp3'; // Path to your notification sound

    // --- Initialization ---
    // Pre-load the audio file to reduce delay when it needs to be played.
    // The 'notificationSound' object is created once and reused.
    const notificationSound = new Audio(soundFileUrl);
    
    // A flag to prevent multiple sounds from playing at once if checks overlap.
    let isPlaying = false;

    /**
     * The core function that makes the API call.
     * It uses the Fetch API to make a GET request to our PHP script.
     */
    function checkForNotifications() {
        fetch(notificationApiUrl)
            .then(response => {
                // Check if the server responded with a success status code (e.g., 200 OK)
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                // Parse the JSON response from the server
                return response.json();
            })
            .then(data => {
                // The server responds with { "new_notification": true } or { "new_notification": false }
                if (data.new_notification && !isPlaying) {
                    console.log('New notification detected from server!');
                    playNotificationSound();

                    // OPTIONAL: Reload the page to show the latest data.
                    // This is a simple but effective way to update the UI.
                    // Uncomment the line below if you want the page to auto-refresh on a new notification.
                    // window.location.reload(); 
                    
                    // OPTIONAL: Show a browser alert.
                    // This can be annoying, so use it sparingly. The sound is often enough.
                    // alert("New Order or Cancellation Request Received!");
                }
            })
            .catch(error => {
                // Log any errors to the browser's console for debugging.
                // This will catch network errors or issues with the server script.
                console.error('Error fetching notifications:', error);
            });
    }

    /**
     * Handles playing the notification sound.
     * Modern browsers have strict autoplay policies and often require a user
     * to interact with the page (like a click) before audio can be played.
     * The .catch() block helps debug issues if the browser blocks playback.
     */
    function playNotificationSound() {
        isPlaying = true;
        notificationSound.play()
            .then(() => {
                // When the sound finishes playing, reset the flag.
                notificationSound.onended = function() {
                    isPlaying = false;
                };
            })
            .catch(error => {
                console.error("Audio playback failed:", error);
                // The most common error is "NotAllowedError: play() failed because the user didn't interact with the document first."
                // In this case, you might need a button on the admin panel like "Enable Sound Notifications"
                // that the user clicks once to grant permission.
                isPlaying = false; // Reset the flag even if it fails
            });
    }

    // --- Start the Polling ---
    // The `setInterval` function repeatedly calls `checkForNotifications`
    // at the interval we defined. This is what makes the system "real-time".
    setInterval(checkForNotifications, checkInterval);

    // You can also run it once immediately on page load if you want.
    // checkForNotifications();
});