<?php
// Handles creating and updating user records from the user management form.

require_once '../config.php';
require_once '../includes/admin_check.php'; // Security check

// 1. VALIDATION
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: /admin/user_management.php");
    exit;
}

// 2. DATA PREPARATION
$id = $_POST['id'] ?? null;
$ba_no = trim($_POST['ba_no']);
$rank = trim($_POST['rank']);
$name = trim($_POST['name']);
$appointment = trim($_POST['appointment']);
$joining_date = trim($_POST['joining_date']);
$mobile_number = trim($_POST['mobile_number']);
$username = trim($_POST['username']);
$password = $_POST['password'];

// 3. LOGIC
// Basic validation
if (empty($ba_no) || empty($rank) || empty($name) || empty($username)) {
    header("Location: /admin/user_management.php?action=" . ($id ? "edit&id=$id" : "add") . "&error=required_fields");
    exit;
}

try {
    if ($id) { // This is an UPDATE operation
        if (!empty($password)) {
            // If a new password is provided, hash it and update the password field.
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET ba_no=?, rank=?, name=?, appointment=?, joining_date=?, mobile_number=?, username=?, password=? WHERE id=?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$ba_no, $rank, $name, $appointment, $joining_date, $mobile_number, $username, $hashed_password, $id]);
        } else {
            // If password is blank, update all other fields but leave the password unchanged.
            $sql = "UPDATE users SET ba_no=?, rank=?, name=?, appointment=?, joining_date=?, mobile_number=?, username=? WHERE id=?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$ba_no, $rank, $name, $appointment, $joining_date, $mobile_number, $username, $id]);
        }
        $message = "update_success";
    } else { // This is a CREATE (add) operation
        if (empty($password)) {
            header("Location: /admin/user_management.php?action=add&error=password_required");
            exit;
        }
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (ba_no, rank, name, appointment, joining_date, mobile_number, username, password, is_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$ba_no, $rank, $name, $appointment, $joining_date, $mobile_number, $username, $hashed_password]);
        $message = "add_success";
    }

    // 4. REDIRECT on success
    header("Location: /admin/user_management.php?message=$message");
    exit();

} catch (PDOException $e) {
    // Handle potential duplicate username/ba_no errors
    if ($e->errorInfo[1] == 1062) {
        $error = "duplicate_entry";
    } else {
        $error = "db_error";
    }
    error_log($e->getMessage());
    header("Location: /admin/user_management.php?action=" . ($id ? "edit&id=$id" : "add") . "&error=$error");
    exit;
}
?>