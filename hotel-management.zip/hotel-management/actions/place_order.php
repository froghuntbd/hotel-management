<?php
// Handles the final submission of a user's food order.

require_once '../config.php';
require_once '../includes/auth_check.php'; // Ensures the user is logged in.

// 1. VALIDATION: Check if the request is a POST and has the required data.
if ($_SERVER["REQUEST_METHOD"] != "POST" || empty($_POST['order'])) {
    // If not, redirect back to the home page.
    header("location: /index.php");
    exit;
}

// 2. DATA PREPARATION
$user_id = $_SESSION['user_id'];
$order_items_data = $_POST['order'];
$total_amount = 0; // Recalculate on the server for security.
$order_date = date("Y-m-d");

try {
    // 3. SERVER-SIDE RECALCULATION & DATA GATHERING
    // This is crucial to prevent users from manipulating prices on the frontend.
    $item_ids = array_column($order_items_data, 'id');
    $placeholders = implode(',', array_fill(0, count($item_ids), '?'));
    
    $sql_prices = "SELECT id, price FROM menu_items WHERE id IN ($placeholders)";
    $stmt_prices = $pdo->prepare($sql_prices);
    $stmt_prices->execute($item_ids);
    $actual_prices = $stmt_prices->fetchAll(PDO::FETCH_KEY_PAIR);

    $final_order_details = [];
    foreach ($order_items_data as $item) {
        $id = $item['id'];
        $quantity = (int)$item['quantity'];

        // Ensure the item exists and quantity is valid
        if (isset($actual_prices[$id]) && $quantity > 0) {
            $price = $actual_prices[$id];
            $subtotal = $price * $quantity;
            $total_amount += $subtotal;
            
            $final_order_details[] = [
                'id' => $id,
                'quantity' => $quantity,
                'price' => $price // Use server-side price
            ];
        }
    }
    
    // If the order is empty after validation, do not proceed.
    if(empty($final_order_details)) {
        throw new Exception("Cannot place an empty order.");
    }

    // 4. DATABASE TRANSACTION
    // A transaction ensures that all SQL queries succeed or none of them do.
    // This prevents creating an 'order' record without any 'order_items'.
    $pdo->beginTransaction();

    // Step A: Insert the main order record into the `orders` table.
    $sql_order = "INSERT INTO orders (user_id, order_date, total_amount, status, created_at, updated_at) VALUES (?, ?, ?, 'pending', NOW(), NOW())";
    $stmt_order = $pdo->prepare($sql_order);
    $stmt_order->execute([$user_id, $order_date, $total_amount]);
    
    // Get the ID of the order we just created.
    $order_id = $pdo->lastInsertId();

    // Step B: Insert each food item into the `order_items` table, linking it to the main order.
    $sql_items = "INSERT INTO order_items (order_id, menu_item_id, quantity, price_at_time_of_order) VALUES (?, ?, ?, ?)";
    $stmt_items = $pdo->prepare($sql_items);

    foreach ($final_order_details as $item) {
        $stmt_items->execute([$order_id, $item['id'], $item['quantity'], $item['price']]);
    }

    // If everything was successful, commit the transaction to save the changes.
    $pdo->commit();
    
    // 5. REDIRECT ON SUCCESS
    // Redirect back to the main menu page with a success message.
    header("Location: /index.php?order=success");
    exit();

} catch (Exception $e) {
    // If any error occurred, roll back the transaction to undo all changes.
    $pdo->rollBack();
    
    // Log the error for the administrator to review.
    error_log("Order placement failed for user_id {$user_id}: " . $e->getMessage());
    
    // Redirect the user to the summary page with an error flag.
    // In a real application, you might pass the POST data back to repopulate the form.
    header("Location: /order_summary.php?error=1");
    exit();
}
?>