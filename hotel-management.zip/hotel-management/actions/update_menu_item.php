<?php
// Handles creating and updating menu item records.

require_once '../config.php';
require_once '../includes/admin_check.php'; // Security check

// 1. VALIDATION
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: /admin/menu_management.php");
    exit;
}

// 2. DATA PREPARATION
$id = $_POST['id'] ?? null;
$name = trim($_POST['name']);
$price = trim($_POST['price']);
$description = trim($_POST['description']);
$is_available = isset($_POST['is_available_today']) ? 1 : 0;

// 3. LOGIC
if (empty($name) || !is_numeric($price) || $price < 0) {
    header("Location: /admin/menu_management.php?action=" . ($id ? "edit&id=$id" : "add") . "&error=validation");
    exit;
}

try {
    if ($id) { // UPDATE operation
        $sql = "UPDATE menu_items SET name = ?, price = ?, description = ?, is_available_today = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$name, $price, $description, $is_available, $id]);
        $message = "update_success";
    } else { // CREATE operation
        $sql = "INSERT INTO menu_items (name, price, description, is_available_today) VALUES (?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$name, $price, $description, $is_available]);
        $message = "add_success";
    }

    // 4. REDIRECT on success
    header("Location: /admin/menu_management.php?message=$message");
    exit();

} catch (PDOException $e) {
    error_log($e->getMessage());
    header("Location: /admin/menu_management.php?action=" . ($id ? "edit&id=$id" : "add") . "&error=db_error");
    exit;
}
?>