<?php
// Handles all order status updates from the admin panel.

require_once '../config.php';
require_once '../includes/admin_check.php'; // Ensures only an admin can run this.

// 1. VALIDATION
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['order_id']) || !isset($_POST['new_status'])) {
    // If the request is invalid, redirect back to the dashboard.
    header("Location: /admin/dashboard.php");
    exit;
}

// 2. DATA PREPARATION
$order_id = $_POST['order_id'];
$new_status = $_POST['new_status'];
$filter_redirect = $_POST['filter'] ?? 'pending'; // To redirect back to the same filtered view

// 3. SECURITY: Define a whitelist of allowed statuses to prevent malicious inputs.
$allowed_statuses = ['confirmed', 'completed', 'cancelled'];
if (!in_array($new_status, $allowed_statuses)) {
    // If the status is not allowed, do nothing and redirect with an error.
    header("Location: /admin/order_management.php?filter={$filter_redirect}&error=invalid_status");
    exit;
}

try {
    // 4. DATABASE UPDATE
    // Update the 'status' and 'updated_at' timestamp for the given order.
    $sql = "UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$new_status, $order_id]);

    // Check if the update was successful
    if ($stmt->rowCount() > 0) {
        $message = "success";
        // Optional: Add logic here to send a notification to the user about the status change.
    } else {
        $message = "no_change";
    }

    // 5. REDIRECT ON SUCCESS
    header("Location: /admin/order_management.php?filter={$filter_redirect}&status_update={$message}");
    exit();

} catch (Exception $e) {
    // Log the error for debugging.
    error_log("Order status update failed for order_id {$order_id}: " . $e->getMessage());
    
    // Redirect with a generic error message.
    header("Location: /admin/order_management.php?filter={$filter_redirect}&error=db_error");
    exit();
}
?>