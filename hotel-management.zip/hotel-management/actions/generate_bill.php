<?php
// Generates a PDF bill voucher, saves it, and creates a record in the database.

require_once '../config.php';
require_once '../includes/admin_check.php'; // Ensures only an admin can run this.
require_once '../lib/fpdf/fpdf.php'; // Include the FPDF library.

// 1. VALIDATION
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['user_id']) || empty($_POST['start_date']) || empty($_POST['end_date'])) {
    die("Invalid request. Please fill out all required fields.");
}

// 2. DATA PREPARATION
$user_id = $_POST['user_id'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$additional_fees = is_numeric($_POST['additional_fees']) ? (float)$_POST['additional_fees'] : 0;

try {
    // 3. FETCH DATA FROM DATABASE
    
    // A. Get User Details
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) { die("User not found."); }

    // B. Get Organization Settings (Logo, Name, Address)
    $settings_stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = $settings_stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    $org_name = $settings['org_name'] ?? 'Mess Management System';
    $org_address = $settings['org_address'] ?? 'Organization Address';
    $logo_path = !empty($settings['org_logo']) ? '../uploads/logos/' . $settings['org_logo'] : null;

    // 4. CALCULATIONS
    
    // A. Calculate Current Month's Food Charges from 'completed' orders within the period.
    $stmt = $pdo->prepare("SELECT SUM(total_amount) as total FROM orders WHERE user_id = ? AND status = 'completed' AND order_date BETWEEN ? AND ?");
    $stmt->execute([$user_id, $start_date, $end_date]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $current_charges = $result['total'] ?? 0;

    // B. Calculate Previous Due Balance
    $stmt = $pdo->prepare("SELECT (SUM(total_due) - SUM(amount_paid)) as due FROM bills WHERE user_id = ? AND status != 'paid' AND period_start_date < ?");
    $stmt->execute([$user_id, $start_date]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $previous_due = $result['due'] ?? 0;

    // C. Calculate Final Total
    $total_due = $previous_due + $current_charges + $additional_fees;

    // 5. PDF GENERATION
    
    // Create a custom PDF class to handle header and footer
    class PDF extends FPDF {
        private $orgName;
        private $orgAddress;
        private $logoPath;

        function setHeaderInfo($name, $address, $logo) {
            $this->orgName = $name;
            $this->orgAddress = $address;
            $this->logoPath = $logo;
        }

        function Header() {
            if ($this->logoPath && file_exists($this->logoPath)) {
                $this->Image($this->logoPath, 10, 8, 30);
            }
            $this->SetFont('Arial', 'B', 16);
            $this->Cell(0, 10, $this->orgName, 0, 1, 'C');
            $this->SetFont('Arial', '', 10);
            $this->Cell(0, 5, $this->orgAddress, 0, 1, 'C');
            $this->Ln(10);
        }

        function Footer() {
            $this->SetY(-15);
            $this->SetFont('Arial', 'I', 8);
            $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
        }
    }

    $pdf = new PDF();
    $pdf->setHeaderInfo($org_name, $org_address, $logo_path);
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Bill Voucher', 0, 1, 'C');
    $pdf->Ln(5);

    // Customer Info
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(40, 7, 'Customer Name:');
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(0, 7, $user['name']);
    $pdf->Ln();
    
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(40, 7, 'Rank / BA No:');
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(0, 7, $user['rank'] . ' / ' . $user['ba_no']);
    $pdf->Ln();

    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(40, 7, 'Billing Period:');
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(0, 7, date("d M, Y", strtotime($start_date)) . ' to ' . date("d M, Y", strtotime($end_date)));
    $pdf->Ln();
    
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(40, 7, 'Bill Date:');
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(0, 7, date("d M, Y"));
    $pdf->Ln(15);
    
    // Billing Details Table
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(130, 8, 'Description', 1, 0, 'C');
    $pdf->Cell(60, 8, 'Amount (' . CURRENCY_SYMBOL . ')', 1, 1, 'C');

    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(130, 8, 'Previous Due Balance', 'LR');
    $pdf->Cell(60, 8, number_format($previous_due, 2), 'R', 1, 'R');
    
    $pdf->Cell(130, 8, 'Food Charges for this Period', 'LR');
    $pdf->Cell(60, 8, number_format($current_charges, 2), 'R', 1, 'R');
    
    $pdf->Cell(130, 8, 'Additional Fees / Other Charges', 'LRB');
    $pdf->Cell(60, 8, number_format($additional_fees, 2), 'RB', 1, 'R');

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(130, 10, 'Total Amount Due', 1, 0, 'R');
    $pdf->Cell(60, 10, number_format($total_due, 2), 1, 1, 'R');

    // 6. SAVE PDF AND DATABASE RECORD
    $file_name = 'bill-' . $user_id . '-' . time() . '.pdf';
    $upload_dir = '../uploads/bills/';
    if (!is_dir($upload_dir)) { mkdir($upload_dir, 0755, true); }
    $file_path = $upload_dir . $file_name;
    
    // Save the PDF to the server
    $pdf->Output('F', $file_path);

    // Save the bill record to the database
    $sql = "INSERT INTO bills (user_id, bill_generation_date, period_start_date, period_end_date, previous_due, current_charges, additional_fees, total_due, pdf_path, status) 
            VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, ?, 'unpaid')";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $start_date, $end_date, $previous_due, $current_charges, $additional_fees, $total_due, 'uploads/bills/' . $file_name]);

    // 7. OUTPUT PDF TO BROWSER
    // This will force the PDF to open in a new tab for printing.
    $pdf->Output('I', $file_name);
    exit;

} catch (Exception $e) {
    error_log("Bill generation failed for user_id {$user_id}: " . $e->getMessage());
    die("An error occurred while generating the bill. Please check the logs.");
}
?>