<?php
// Turn on error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session on every page
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// --- DATABASE CREDENTIALS (REPLACE WITH YOURS) ---
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // <-- Replace with your database username
define('DB_PASS', '');      // <-- Replace with your database password
define('DB_NAME', 'hotel_management'); // <-- Replace with your database name

// --- SITE SETTINGS ---
// IMPORTANT: Replace with your live URL when you deploy
define('SITE_URL', 'http://localhost/hotel-management'); 
define('CURRENCY_SYMBOL', 'BDT');

// --- DATABASE CONNECTION (using PDO for security) ---
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET CHARACTER SET utf8mb4");
} catch(PDOException $e){
    die("ERROR: Could not connect to the database. " . $e->getMessage());
}
?>