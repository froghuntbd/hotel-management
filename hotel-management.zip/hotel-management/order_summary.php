<?php
require_once 'config.php';
require_once 'includes/auth_check.php';

if ($_SERVER["REQUEST_METHOD"] != "POST" || empty($_POST['items'])) {
    header("location: index.php");
    exit;
}

$ordered_items = $_POST['items'];
$order_details = [];
$total_amount = 0;

$ids = array_keys($ordered_items);
if (!empty($ids)) {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $sql = "SELECT id, name, price FROM menu_items WHERE id IN ($placeholders)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($ids);
    $menu_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($menu_items as $item) {
        $id = $item['id'];
        $quantity = (int)$ordered_items[$id]['quantity'];
        if ($quantity > 0) {
            $order_details[] = [
                'id' => $id,
                'name' => $item['name'],
                'price' => $item['price'],
                'quantity' => $quantity,
                'subtotal' => $item['price'] * $quantity
            ];
            $total_amount += $item['price'] * $quantity;
        }
    }
}

if (empty($order_details)) {
    // If user checked boxes but set quantity to 0
    header("location: index.php");
    exit;
}

$page_title = "Order Summary";
require_once 'includes/header.php';
?>

<div class="container mt-4">
    <h1>Order Summary</h1>
    <p>Please review your order below before submitting.</p>

    <div class="card">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th class="text-center">Quantity</th>
                        <th class="text-end">Price</th>
                        <th class="text-end">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($order_details as $detail): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($detail['name']); ?></td>
                            <td class="text-center"><?php echo $detail['quantity']; ?></td>
                            <td class="text-end"><?php echo CURRENCY_SYMBOL; ?> <?php echo number_format($detail['price'], 2); ?></td>
                            <td class="text-end"><?php echo CURRENCY_SYMBOL; ?> <?php echo number_format($detail['subtotal'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="3" class="text-end">Total Amount:</th>
                        <th class="text-end fs-5"><?php echo CURRENCY_SYMBOL; ?> <?php echo number_format($total_amount, 2); ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <form action="actions/place_order.php" method="post" class="mt-4">
        <?php foreach ($order_details as $index => $detail): ?>
            <input type="hidden" name="order[<?php echo $index; ?>][id]" value="<?php echo $detail['id']; ?>">
            <input type="hidden" name="order[<?php echo $index; ?>][quantity]" value="<?php echo $detail['quantity']; ?>">
            <input type="hidden" name="order[<?php echo $index; ?>][price]" value="<?php echo $detail['price']; ?>">
        <?php endforeach; ?>
        <input type="hidden" name="total_amount" value="<?php echo $total_amount; ?>">
        
        <div class="d-flex justify-content-between">
            <a href="index.php" class="btn btn-secondary">&laquo; Go Back & Edit</a>
            <button type="submit" class="btn btn-success btn-lg">Submit Order</button>
        </div>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>