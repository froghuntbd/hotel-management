<?php
/**
 * File: api/check_notifications.php
 *
 * Purpose: API endpoint for checking bill notifications.
 *
 * This script checks for any bills that are either overdue or due within the next 7 days
 * for the logged-in user's organization. It's intended to be called by JavaScript
 * to trigger a sound alert or visual notification in the UI.
 *
 * Output: JSON
 *  - {"notification": true}  if there are pending/overdue bills.
 *  - {"notification": false} if all bills are paid and not due soon.
 *  - {"error": "..."}      if the user is not authenticated or a DB error occurs.
 */

header('Content-Type: application/json');
session_start();

// 1. Authentication Check: Ensure a user is logged in.
if (!isset($_SESSION['user_id']) || !isset($_SESSION['organization_id'])) {
    http_response_code(403); // Forbidden
    echo json_encode(['error' => 'Authentication required.']);
    exit;
}

// 2. Include Database Configuration
// The path is relative to this file's location in the 'api' directory.
require_once __DIR__ . '/../config/database.php';

$organization_id = $_SESSION['organization_id'];
$notification_found = false;

try {
    // 3. Prepare the SQL Query
    // We want to find bills that meet two criteria for the current organization:
    // - The status is NOT 'Paid'.
    // - AND (The due_date is in the past (overdue) OR the due_date is within the next 7 days).
    // We only need to know if at least ONE such bill exists, so `SELECT 1` is efficient.
    $sql = "SELECT 1 
            FROM bills 
            WHERE organization_id = :organization_id 
              AND status != 'Paid'
              AND (due_date < CURDATE() OR due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY))
            LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':organization_id', $organization_id, PDO::PARAM_INT);
    $stmt->execute();

    // 4. Check the result
    // If fetch() returns a result, it means at least one matching bill was found.
    if ($stmt->fetch()) {
        $notification_found = true;
    }

} catch (PDOException $e) {
    // In a production environment, you would log this error instead of echoing it.
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Database query failed.']);
    // For debugging: error_log('Notification check failed: ' . $e->getMessage());
    exit;
}

// 5. Return the JSON response
echo json_encode(['notification' => $notification_found]);
