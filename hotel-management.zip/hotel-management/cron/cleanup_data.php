<?php
/**
 * File: cron/cleanup_data.php
 *
 * Purpose: Cron job script for routine data cleanup.
 *
 * This script should be executed on a schedule (e.g., daily) by a server cron job.
 * It deletes bill records and their corresponding file uploads that are older than 90 days
 * AND have a status of 'Paid'. This prevents accidental deletion of old but unpaid bills.
 *
 * IMPORTANT: This script should ONLY be run from the command line (CLI) for security.
 *
 * Example Cron Job (runs every day at 3:00 AM):
 * 0 3 * * * /usr/bin/php /var/www/html/your_project/cron/cleanup_data.php
 */

// 1. Security Check: Ensure this script is run from the command line, not a browser.
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    die("Access Denied: This script is intended for command-line execution only.");
}

// 2. Include Database Configuration & Set Timezone
// The path is relative to this file's location in the 'cron' directory.
require_once __DIR__ . '/../config/database.php';
date_default_timezone_set('UTC'); // Or your application's default timezone

echo "--- Starting Data Cleanup Cron Job: " . date('Y-m-d H:i:s') . " ---\n";

$days_to_keep = 90;
$cutoff_date = date('Y-m-d H:i:s', strtotime("-$days_to_keep days"));
$uploads_dir = __DIR__ . '/../uploads/bills/';
$deleted_files_count = 0;
$deleted_records_count = 0;

try {
    // 3. Use a transaction for data integrity.
    // If deleting a file fails, we can roll back the database change.
    $pdo->beginTransaction();

    // 4. Find all paid bills older than the cutoff date.
    // We select the attachment path to delete the file first.
    // Business Logic: Only delete records where status is 'Paid' and the paid_at date is before our cutoff.
    $sql_select = "SELECT id, attachment_path FROM bills WHERE status = 'Paid' AND paid_at < :cutoff_date";
    $stmt_select = $pdo->prepare($sql_select);
    $stmt_select->bindParam(':cutoff_date', $cutoff_date, PDO::PARAM_STR);
    $stmt_select->execute();
    
    $bills_to_delete = $stmt_select->fetchAll(PDO::FETCH_ASSOC);

    if (empty($bills_to_delete)) {
        echo "No paid bills older than $days_to_keep days found to delete.\n";
        $pdo->commit(); // Still need to commit the (empty) transaction.
        echo "--- Cleanup Job Finished ---\n";
        exit;
    }

    $bill_ids_to_delete = [];

    // 5. Loop through the found bills and delete their associated files.
    echo "Found " . count($bills_to_delete) . " records to process...\n";
    foreach ($bills_to_delete as $bill) {
        if (!empty($bill['attachment_path'])) {
            $file_path = $uploads_dir . $bill['attachment_path'];

            if (file_exists($file_path) && is_file($file_path)) {
                if (unlink($file_path)) {
                    echo "Successfully deleted file: " . $bill['attachment_path'] . "\n";
                    $deleted_files_count++;
                } else {
                    // If file deletion fails, throw an exception to trigger a rollback.
                    throw new Exception("Failed to delete file: " . $file_path);
                }
            } else {
                echo "Warning: File not found for bill ID " . $bill['id'] . ", but will proceed with DB record deletion: " . $bill['attachment_path'] . "\n";
            }
        }
        $bill_ids_to_delete[] = $bill['id'];
    }

    // 6. Delete the database records for the processed bills.
    if (!empty($bill_ids_to_delete)) {
        // Use an IN clause to delete all matched IDs in a single query.
        $placeholders = implode(',', array_fill(0, count($bill_ids_to_delete), '?'));
        $sql_delete = "DELETE FROM bills WHERE id IN ($placeholders)";
        
        $stmt_delete = $pdo->prepare($sql_delete);
        $stmt_delete->execute($bill_ids_to_delete);
        
        $deleted_records_count = $stmt_delete->rowCount();
    }

    // 7. Commit the transaction if all operations were successful.
    $pdo->commit();

    echo "\n--- Summary ---\n";
    echo "Successfully deleted $deleted_records_count database records.\n";
    echo "Successfully deleted $deleted_files_count associated files.\n";

} catch (Exception $e) {
    // 8. An error occurred, roll back all database changes.
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "\n--- ERROR ---\n";
    echo "An error occurred: " . $e->getMessage() . "\n";
    echo "Transaction rolled back. No data has been deleted from the database.\n";
    // Log this error to a file for review.
    error_log("Cron Job Failed: " . $e->getMessage());
    exit(1); // Exit with a non-zero status to indicate failure
}

echo "--- Cleanup Job Finished Successfully ---\n";
