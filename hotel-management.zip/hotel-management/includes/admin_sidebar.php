<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="d-flex flex-column flex-shrink-0 p-3 bg-light" style="width: 280px;">
    <a href="/admin/dashboard.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
        <span class="fs-4">Admin Panel</span>
    </a>
    <hr>
    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item">
            <a href="/admin/dashboard.php" class="nav-link <?php echo $current_page == 'dashboard.php' ? 'active' : 'link-dark'; ?>">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </li>
        <li>
            <a href="/admin/order_management.php" class="nav-link <?php echo $current_page == 'order_management.php' ? 'active' : 'link-dark'; ?>">
                <i class="bi bi-card-list"></i> Order Management
            </a>
        </li>
        <li>
            <a href="/admin/menu_management.php" class="nav-link <?php echo $current_page == 'menu_management.php' ? 'active' : 'link-dark'; ?>">
                <i class="bi bi-journal-album"></i> Menu Management
            </a>
        </li>
        <li>
            <a href="/admin/user_management.php" class="nav-link <?php echo $current_page == 'user_management.php' ? 'active' : 'link-dark'; ?>">
                <i class="bi bi-people"></i> User Management
            </a>
        </li>
        <li>
            <a href="/admin/billing.php" class="nav-link <?php echo $current_page == 'billing.php' ? 'active' : 'link-dark'; ?>">
                <i class="bi bi-receipt"></i> Billing & Vouchers
            </a>
        </li>
        <li>
            <a href="/admin/settings.php" class="nav-link <?php echo $current_page == 'settings.php' ? 'active' : 'link-dark'; ?>">
                <i class="bi bi-gear"></i> Settings
            </a>
        </li>
    </ul>
</div>