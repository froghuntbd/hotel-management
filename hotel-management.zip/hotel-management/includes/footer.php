</div> <!-- end .main-content -->

<footer class="footer mt-auto py-3 bg-light text-center">
    <div class="container">
        <span class="text-muted">&copy; <?php echo date("Y"); ?> Mess Management System. All rights reserved.</span>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/app.js"></script>

<?php
// Conditionally load admin-specific scripts
if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === 1) {
    echo '<script src="/assets/js/notification.js"></script>';
}
?>

</body>
</html>