<?php
// This file checks if the user is an admin.
// It assumes auth_check.php is already included or will be.
if (session_status() == PHP_SESSION_NONE) { session_start(); }

if (!isset($_SESSION["user_id"])) {
    header("location: /login.php");
    exit;
}

if (!isset($_SESSION["is_admin"]) || $_SESSION["is_admin"] != 1) {
    echo "Access Denied. You do not have permission to view this page.";
    // Optionally redirect to user dashboard
    header("refresh:3;url=/index.php"); 
    exit;
}
?>