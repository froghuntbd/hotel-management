<?php
// This file is included on pages that require login
if (!isset($_SESSION["user_id"])) {
    header("location: /login.php");
    exit;
}
?>