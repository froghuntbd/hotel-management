<?php
require_once '../config.php';
require_once '../includes/admin_check.php';

$action = $_GET['action'] ?? 'view';
$user_id = $_GET['id'] ?? null;
$message = '';
$error = '';

// Handle form submissions for add/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $ba_no = trim($_POST['ba_no']);
    $rank = trim($_POST['rank']);
    $name = trim($_POST['name']);
    $appointment = trim($_POST['appointment']);
    $joining_date = trim($_POST['joining_date']);
    $mobile_number = trim($_POST['mobile_number']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Basic validation
    if (empty($ba_no) || empty($rank) || empty($name) || empty($username)) {
        $error = "BA No, Rank, Name, and Username are required.";
    } else {
        if ($id) { // Update existing user
            if (!empty($password)) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $sql = "UPDATE users SET ba_no=?, rank=?, name=?, appointment=?, joining_date=?, mobile_number=?, username=?, password=? WHERE id=?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$ba_no, $rank, $name, $appointment, $joining_date, $mobile_number, $username, $hashed_password, $id]);
            } else {
                $sql = "UPDATE users SET ba_no=?, rank=?, name=?, appointment=?, joining_date=?, mobile_number=?, username=? WHERE id=?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$ba_no, $rank, $name, $appointment, $joining_date, $mobile_number, $username, $id]);
            }
            $message = "User updated successfully!";
        } else { // Add new user
            if (empty($password)) {
                $error = "Password is required for new users.";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $sql = "INSERT INTO users (ba_no, rank, name, appointment, joining_date, mobile_number, username, password, is_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$ba_no, $rank, $name, $appointment, $joining_date, $mobile_number, $username, $hashed_password]);
                $message = "New user created successfully!";
            }
        }
        if (empty($error)) $action = 'view';
    }
}

// Handle delete action
if ($action === 'delete' && $user_id) {
    // Basic protection against deleting oneself or other admins.
    $stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user_to_delete = $stmt->fetch();
    if ($user_to_delete && $user_to_delete['is_admin'] == 0) {
        $sql = "DELETE FROM users WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$user_id]);
        $message = "User deleted successfully!";
    } else {
        $error = "Cannot delete an admin user.";
    }
    $action = 'view';
}

// Fetch data for view/edit
$users = [];
$user_to_edit = null;
if ($action === 'view') {
    $users = $pdo->query("SELECT * FROM users WHERE is_admin = 0 ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} elseif (($action === 'edit' || $action === 'add') && $user_id) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user_to_edit = $stmt->fetch(PDO::FETCH_ASSOC);
}

$page_title = "User Management";
require_once '../includes/header.php';
?>
<div class="d-flex">
    <?php require_once '../includes/admin_sidebar.php'; ?>
    <div class="container-fluid p-4">
        <h1 class="mb-4">User Management</h1>

        <?php if ($message): ?><div class="alert alert-success"><?php echo $message; ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>

        <?php if ($action === 'add' || $action === 'edit'): ?>
            <h3><?php echo $action === 'add' ? 'Add New User' : 'Edit User'; ?></h3>
            <form action="user_management.php" method="post" class="card p-3">
                <input type="hidden" name="id" value="<?php echo $user_to_edit['id'] ?? ''; ?>">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user_to_edit['name'] ?? ''); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="ba_no" class="form-label">BA No:</label>
                        <input type="text" class="form-control" id="ba_no" name="ba_no" value="<?php echo htmlspecialchars($user_to_edit['ba_no'] ?? ''); ?>" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="rank" class="form-label">Rank</label>
                        <input type="text" class="form-control" id="rank" name="rank" value="<?php echo htmlspecialchars($user_to_edit['rank'] ?? ''); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="appointment" class="form-label">Appointment</label>
                        <input type="text" class="form-control" id="appointment" name="appointment" value="<?php echo htmlspecialchars($user_to_edit['appointment'] ?? ''); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="joining_date" class="form-label">Joining Date</label>
                        <input type="date" class="form-control" id="joining_date" name="joining_date" value="<?php echo htmlspecialchars($user_to_edit['joining_date'] ?? ''); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="mobile_number" class="form-label">Mobile Number</label>
                        <input type="text" class="form-control" id="mobile_number" name="mobile_number" value="<?php echo htmlspecialchars($user_to_edit['mobile_number'] ?? ''); ?>">
                    </div>
                </div>
                <hr>
                <h5>Login Credentials</h5>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user_to_edit['username'] ?? ''); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" <?php echo $action === 'add' ? 'required' : ''; ?>>
                        <?php if ($action === 'edit'): ?><small class="form-text text-muted">Leave blank to keep current password.</small><?php endif; ?>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Save User</button>
                <a href="user_management.php" class="btn btn-secondary mt-2">Cancel</a>
            </form>
        <?php else: ?>
            <a href="?action=add" class="btn btn-primary mb-3"><i class="bi bi-person-plus"></i> Add New User</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead><tr><th>Name</th><th>Rank</th><th>BA No:</th><th>Username</th><th>Mobile</th><th>Actions</th></tr></thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['rank']); ?></td>
                                        <td><?php echo htmlspecialchars($user['ba_no']); ?></td>
                                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                                        <td><?php echo htmlspecialchars($user['mobile_number']); ?></td>
                                        <td>
                                            <a href="?action=edit&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                            <a href="?action=delete&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-outline-danger delete-btn" title="Delete"><i class="bi bi-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>