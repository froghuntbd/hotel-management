<?php
require_once '../config.php';
require_once '../includes/admin_check.php';

$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update Organization Name and Address
    $org_name = $_POST['org_name'];
    $org_address = $_POST['org_address'];

    $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
    $stmt->execute([$org_name, 'org_name']);
    $stmt->execute([$org_address, 'org_address']);

    // Handle Logo Upload
    if (isset($_FILES['org_logo']) && $_FILES['org_logo']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        if (in_array($_FILES['org_logo']['type'], $allowed_types)) {
            $upload_dir = '../uploads/logos/';
            // Create directory if it doesn't exist
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            $file_extension = pathinfo($_FILES['org_logo']['name'], PATHINFO_EXTENSION);
            $new_filename = 'logo.' . $file_extension;
            $destination = $upload_dir . $new_filename;
            
            // Delete old logo if it exists with a different extension
            $old_logos = glob($upload_dir . "logo.*");
            foreach($old_logos as $old_logo) {
                if(basename($old_logo) != $new_filename) {
                   unlink($old_logo);
                }
            }

            if (move_uploaded_file($_FILES['org_logo']['tmp_name'], $destination)) {
                $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'org_logo'");
                $stmt->execute([$new_filename]);
                $message = "Settings updated successfully!";
            } else {
                $error = "Failed to upload logo.";
            }
        } else {
            $error = "Invalid file type for logo. Please use JPG, PNG, or GIF.";
        }
    } else {
         $message = "Settings updated successfully!";
    }
}

// Fetch current settings
$settings_stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
$settings = $settings_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$page_title = "System Settings";
require_once '../includes/header.php';
?>
<div class="d-flex">
    <?php require_once '../includes/admin_sidebar.php'; ?>
    <div class="container-fluid p-4">
        <h1 class="mb-4">System Settings</h1>

        <?php if ($message): ?><div class="alert alert-success"><?php echo $message; ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
        
        <div class="card">
            <div class="card-body">
                <form action="settings.php" method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="org_name" class="form-label">Organization Name</label>
                        <input type="text" class="form-control" id="org_name" name="org_name" value="<?php echo htmlspecialchars($settings['org_name'] ?? ''); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="org_address" class="form-label">Organization Address</label>
                        <textarea class="form-control" id="org_address" name="org_address" rows="3"><?php echo htmlspecialchars($settings['org_address'] ?? ''); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="org_logo" class="form-label">Organization Logo</label>
                        <input class="form-control" type="file" id="org_logo" name="org_logo">
                        <small class="form-text text-muted">Upload a new logo to replace the current one. Use PNG, JPG, or GIF.</small>
                    </div>
                    <?php if (!empty($settings['org_logo']) && file_exists('../uploads/logos/' . $settings['org_logo'])): ?>
                        <div class="mb-3">
                            <strong>Current Logo:</strong><br>
                            <img src="/uploads/logos/<?php echo $settings['org_logo']; ?>?t=<?php echo time(); ?>" alt="Current Logo" style="max-height: 100px; background-color: #f0f0f0; padding: 10px; border-radius: 5px;">
                        </div>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary">Save Settings</button>
                </form>
            </div>
        </div>

    </div>
</div>
<?php require_once '../includes/footer.php'; ?>