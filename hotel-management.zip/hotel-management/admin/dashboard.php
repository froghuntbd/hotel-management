<?php
require_once '../config.php';
require_once '../includes/admin_check.php';

// --- DATA FETCHING FOR DASHBOARD CARDS (Last 30 Days) ---
$thirtyDaysAgo = date('Y-m-d H:i:s', strtotime('-30 days'));

// Total Orders
$totalOrdersStmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE created_at >= ?");
$totalOrdersStmt->execute([$thirtyDaysAgo]);
$totalOrders = $totalOrdersStmt->fetchColumn();

// New Orders (Pending)
$newOrdersStmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE status = 'pending' AND created_at >= ?");
$newOrdersStmt->execute([$thirtyDaysAgo]);
$newOrders = $newOrdersStmt->fetchColumn();

// Canceled Orders
$canceledOrdersStmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE status = 'cancelled' AND created_at >= ?");
$canceledOrdersStmt->execute([$thirtyDaysAgo]);
$canceledOrders = $canceledOrdersStmt->fetchColumn();

// Completed Orders
$completedOrdersStmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE status = 'completed' AND created_at >= ?");
$completedOrdersStmt->execute([$thirtyDaysAgo]);
$completedOrders = $completedOrdersStmt->fetchColumn();

// Total Customers (non-admin users)
$totalCustomers = $pdo->query("SELECT COUNT(*) FROM users WHERE is_admin = 0")->fetchColumn();

// Total Menu Items
$totalMenuItems = $pdo->query("SELECT COUNT(*) FROM menu_items")->fetchColumn();


// --- DATA FOR CHART (Daily orders for the last 30 days) ---
$daily_orders_sql = "SELECT DATE(order_date) as date, COUNT(*) as count FROM orders WHERE order_date >= ? GROUP BY DATE(order_date) ORDER BY date ASC";
$daily_orders_stmt = $pdo->prepare($daily_orders_sql);
$daily_orders_stmt->execute([date('Y-m-d', strtotime('-30 days'))]);
$daily_orders_data = $daily_orders_stmt->fetchAll(PDO::FETCH_ASSOC);

$chart_labels = [];
$chart_data = [];
// Create a 30-day template to ensure all days are shown, even with 0 orders
$date_template = [];
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $date_template[$date] = 0;
}
// Fill the template with actual data
foreach ($daily_orders_data as $data) {
    $date_template[$data['date']] = $data['count'];
}
// Prepare for Chart.js
foreach ($date_template as $date => $count) {
    $chart_labels[] = date("M d", strtotime($date));
    $chart_data[] = $count;
}


$page_title = "Admin Dashboard";
require_once '../includes/header.php';
?>

<div class="d-flex">
    <?php require_once '../includes/admin_sidebar.php'; ?>
    <div class="container-fluid p-4">
        <h1 class="mb-4">Dashboard</h1>
        
        <!-- Stats Cards -->
        <div class="row">
            <div class="col-xl-4 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs fw-bold text-primary text-uppercase mb-1">Total Orders (30d)</div>
                                <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $totalOrders; ?></div>
                            </div>
                            <div class="col-auto"><i class="bi bi-calendar-check fs-2 text-secondary"></i></div>
                        </div>
                    </div>
                </div>
            </div>
             <div class="col-xl-4 col-md-6 mb-4">
                <div class="card border-left-success shadow h-100 py-2">
                     <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs fw-bold text-success text-uppercase mb-1">Completed Orders (30d)</div>
                                <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $completedOrders; ?></div>
                            </div>
                            <div class="col-auto"><i class="bi bi-check2-circle fs-2 text-secondary"></i></div>
                        </div>
                    </div>
                </div>
            </div>
             <div class="col-xl-4 col-md-6 mb-4">
                <div class="card border-left-danger shadow h-100 py-2">
                     <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs fw-bold text-danger text-uppercase mb-1">Canceled Orders (30d)</div>
                                <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $canceledOrders; ?></div>
                            </div>
                            <div class="col-auto"><i class="bi bi-x-circle fs-2 text-secondary"></i></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                     <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs fw-bold text-info text-uppercase mb-1">Total Customers</div>
                                <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $totalCustomers; ?></div>
                            </div>
                            <div class="col-auto"><i class="bi bi-people-fill fs-2 text-secondary"></i></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                     <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs fw-bold text-warning text-uppercase mb-1">Pending Orders</div>
                                <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $newOrders; ?></div>
                            </div>
                            <div class="col-auto"><i class="bi bi-hourglass-split fs-2 text-secondary"></i></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6 mb-4">
                <div class="card border-left-secondary shadow h-100 py-2">
                     <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs fw-bold text-secondary text-uppercase mb-1">Total Menu Items</div>
                                <div class="h5 mb-0 fw-bold text-gray-800"><?php echo $totalMenuItems; ?></div>
                            </div>
                            <div class="col-auto"><i class="bi bi-journal-album fs-2 text-secondary"></i></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 fw-bold text-primary">Daily Orders (Last 30 Days)</h6>
                    </div>
                    <div class="card-body">
                        <div style="height: 350px;">
                            <canvas id="dailyOrdersChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById('dailyOrdersChart').getContext('2d');
    const dailyOrdersChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($chart_labels); ?>,
            datasets: [{
                label: 'Orders',
                data: <?php echo json_encode($chart_data); ?>,
                backgroundColor: 'rgba(78, 115, 223, 0.05)',
                borderColor: 'rgba(78, 115, 223, 1)',
                borderWidth: 2,
                pointRadius: 3,
                pointBackgroundColor: "rgba(78, 115, 223, 1)",
                tension: 0.3
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>
