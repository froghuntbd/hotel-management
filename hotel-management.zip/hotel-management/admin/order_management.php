<?php
require_once '../config.php';
require_once '../includes/admin_check.php';

$message = '';
// Handle status updates from form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['new_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['new_status'];
    
    $allowed_statuses = ['confirmed', 'completed', 'cancelled'];
    if (in_array($new_status, $allowed_statuses)) {
        $sql = "UPDATE orders SET status = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$new_status, $order_id]);
        $message = "Order #$order_id status updated to '$new_status'.";
    }
}

$filter = $_GET['filter'] ?? 'pending';
$allowed_filters = ['pending', 'cancellation_requested', 'confirmed', 'completed', 'cancelled'];
if (!in_array($filter, $allowed_filters)) {
    $filter = 'pending'; // Default to pending if filter is invalid
}

$sql = "SELECT o.id, o.created_at, o.total_amount, o.status, u.name as user_name, u.rank, u.ba_no
        FROM orders o
        JOIN users u ON o.user_id = u.id
        WHERE o.status = ?
        ORDER BY o.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$filter]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Order Management";
require_once '../includes/header.php';
?>
<div class="d-flex">
    <?php require_once '../includes/admin_sidebar.php'; ?>
    <div class="container-fluid p-4">
        <h1 class="mb-4">Order Management</h1>

        <?php if ($message): ?><div class="alert alert-success"><?php echo $message; ?></div><?php endif; ?>

        <div class="btn-group mb-4 shadow-sm" role="group">
            <a href="?filter=pending" class="btn <?php echo $filter == 'pending' ? 'btn-primary' : 'btn-outline-primary'; ?>">New Orders</a>
            <a href="?filter=cancellation_requested" class="btn <?php echo $filter == 'cancellation_requested' ? 'btn-warning text-dark' : 'btn-outline-warning'; ?>">Cancellation Requests</a>
            <a href="?filter=confirmed" class="btn <?php echo $filter == 'confirmed' ? 'btn-info text-dark' : 'btn-outline-info'; ?>">Confirmed</a>
            <a href="?filter=completed" class="btn <?php echo $filter == 'completed' ? 'btn-success' : 'btn-outline-success'; ?>">Completed</a>
            <a href="?filter=cancelled" class="btn <?php echo $filter == 'cancelled' ? 'btn-danger' : 'btn-outline-danger'; ?>">Cancelled</a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Timestamp</th>
                                <th>Items</th>
                                <th class="text-end">Total</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($orders) > 0): ?>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td>#<?php echo $order['id']; ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($order['user_name']); ?></strong><br>
                                            <small class="text-muted"><?php echo htmlspecialchars($order['rank']); ?> (BA: <?php echo htmlspecialchars($order['ba_no']); ?>)</small>
                                        </td>
                                        <td><?php echo date("d M Y, h:i A", strtotime($order['created_at'])); ?></td>
                                        <td>
                                            <ul class="list-unstyled mb-0 small">
                                            <?php 
                                                $item_sql = "SELECT mi.name, oi.quantity FROM order_items oi JOIN menu_items mi ON oi.menu_item_id = mi.id WHERE oi.order_id = ?";
                                                $item_stmt = $pdo->prepare($item_sql);
                                                $item_stmt->execute([$order['id']]);
                                                $items = $item_stmt->fetchAll(PDO::FETCH_ASSOC);
                                                foreach ($items as $item) { echo '<li>' . htmlspecialchars($item['name']) . ' (x' . $item['quantity'] . ')</li>'; }
                                            ?>
                                            </ul>
                                        </td>
                                        <td class="text-end fw-bold"><?php echo CURRENCY_SYMBOL; ?> <?php echo number_format($order['total_amount'], 2); ?></td>
                                        <td>
                                            <form action="order_management.php?filter=<?php echo $filter; ?>" method="POST" class="d-inline">
                                                <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                <div class="btn-group">
                                                    <?php if ($filter === 'pending' || $filter === 'cancellation_requested'): ?>
                                                        <button type="submit" name="new_status" value="confirmed" class="btn btn-sm btn-success">Confirm</button>
                                                    <?php endif; ?>
                                                    <?php if ($filter === 'confirmed'): ?>
                                                        <button type="submit" name="new_status" value="completed" class="btn btn-sm btn-primary">Food Served</button>
                                                    <?php endif; ?>
                                                    <?php if ($filter !== 'completed' && $filter !== 'cancelled'): ?>
                                                        <button type="submit" name="new_status" value="cancelled" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to cancel this order?')">Cancel</button>
                                                    <?php endif; ?>
                                                </div>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="text-center p-4">No orders found with '<?php echo $filter; ?>' status.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>