<?php
require_once '../config.php';
require_once '../includes/admin_check.php';

// Handle marking a bill as paid
if (isset($_POST['action']) && $_POST['action'] === 'mark_paid') {
    $bill_id = $_POST['bill_id'];
    $amount_paid = $_POST['amount_paid'];
    
    // Fetch bill details to determine new status
    $stmt = $pdo->prepare("SELECT total_due FROM bills WHERE id = ?");
    $stmt->execute([$bill_id]);
    $bill = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $new_status = ($amount_paid >= $bill['total_due']) ? 'paid' : 'partially_paid';

    $sql = "UPDATE bills SET amount_paid = ?, status = ? WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$amount_paid, $new_status, $bill_id]);
    
    header("Location: billing.php?success=paid");
    exit();
}

// Fetch all non-admin users for the dropdown
$users = $pdo->query("SELECT id, name, rank, ba_no FROM users WHERE is_admin = 0 ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch all generated bills
$bills = $pdo->query("
    SELECT b.*, u.name as user_name, u.rank 
    FROM bills b 
    JOIN users u ON b.user_id = u.id 
    ORDER BY b.bill_generation_date DESC
")->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Billing & Vouchers";
require_once '../includes/header.php';
?>
<div class="d-flex">
    <?php require_once '../includes/admin_sidebar.php'; ?>
    <div class="container-fluid p-4">
        <h1 class="mb-4">Billing & Vouchers</h1>

        <?php if (isset($_GET['success']) && $_GET['success'] == 'generated'): ?>
            <div class="alert alert-success">Bill voucher generated successfully!</div>
        <?php elseif (isset($_GET['success']) && $_GET['success'] == 'paid'): ?>
            <div class="alert alert-success">Bill status updated successfully!</div>
        <?php endif; ?>
        
        <!-- Bill Generation Form -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>Generate New Bill Voucher</h3>
            </div>
            <div class="card-body">
                <form action="../actions/generate_bill.php" method="post" target="_blank">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="user_id" class="form-label">Select Customer</label>
                            <select class="form-select" id="user_id" name="user_id" required>
                                <option value="">-- Select a User --</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['id']; ?>">
                                        <?php echo htmlspecialchars($user['name']) . " (" . htmlspecialchars($user['rank']) . ")"; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="start_date" class="form-label">Billing Period Start</label>
                            <input type="date" class="form-control" id="start_date" name="start_date" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="end_date" class="form-label">Billing Period End</label>
                            <input type="date" class="form-control" id="end_date" name="end_date" required>
                        </div>
                         <div class="col-md-2 mb-3">
                            <label for="additional_fees" class="form-label">Other Fees</label>
                            <input type="number" step="0.01" class="form-control" id="additional_fees" name="additional_fees" value="0.00">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-file-earmark-pdf"></i> Generate & Print Voucher</button>
                </form>
            </div>
        </div>

        <!-- Generated Bills List -->
        <div class="card">
            <div class="card-header">
                <h3>Generated Bills History</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr><th>Bill ID</th><th>Customer</th><th>Period</th><th class="text-end">Total Due</th><th class="text-end">Amount Paid</th><th>Status</th><th>Actions</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach($bills as $bill): ?>
                                <tr>
                                    <td>#<?php echo $bill['id']; ?></td>
                                    <td><?php echo htmlspecialchars($bill['user_name']); ?></td>
                                    <td><?php echo date("d M Y", strtotime($bill['period_start_date'])) . " - " . date("d M Y", strtotime($bill['period_end_date'])); ?></td>
                                    <td class="text-end fw-bold"><?php echo number_format($bill['total_due'], 2); ?></td>
                                    <td class="text-end"><?php echo number_format($bill['amount_paid'], 2); ?></td>
                                    <td>
                                        <?php 
                                        $status_class = 'bg-danger';
                                        if ($bill['status'] == 'paid') $status_class = 'bg-success';
                                        if ($bill['status'] == 'partially_paid') $status_class = 'bg-warning text-dark';
                                        ?>
                                        <span class="badge <?php echo $status_class; ?>"><?php echo ucfirst($bill['status']); ?></span>
                                    </td>
                                    <td>
                                        <a href="/<?php echo $bill['pdf_path']; ?>" class="btn btn-sm btn-info" target="_blank" title="View PDF"><i class="bi bi-eye"></i></a>
                                        <?php if($bill['status'] != 'paid'): ?>
                                            <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#paymentModal" data-bill-id="<?php echo $bill['id']; ?>" data-total-due="<?php echo $bill['total_due']; ?>" title="Mark as Paid"><i class="bi bi-cash-coin"></i></button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Mark Bill as Paid</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="billing.php" method="post">
                <div class="modal-body">
                    <input type="hidden" name="action" value="mark_paid">
                    <input type="hidden" name="bill_id" id="modal_bill_id">
                    <div class="mb-3">
                        <label for="amount_paid" class="form-label">Amount Paid (<?php echo CURRENCY_SYMBOL; ?>)</label>
                        <input type="number" step="0.01" class="form-control" id="modal_amount_paid" name="amount_paid" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var paymentModal = document.getElementById('paymentModal');
    paymentModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget;
        var billId = button.getAttribute('data-bill-id');
        var totalDue = button.getAttribute('data-total-due');

        var modalBillIdInput = paymentModal.querySelector('#modal_bill_id');
        var modalAmountPaidInput = paymentModal.querySelector('#modal_amount_paid');

        modalBillIdInput.value = billId;
        modalAmountPaidInput.value = totalDue; // Pre-fill with the total due amount
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>