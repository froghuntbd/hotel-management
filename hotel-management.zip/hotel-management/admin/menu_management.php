<?php
require_once '../config.php';
require_once '../includes/admin_check.php';

$action = $_GET['action'] ?? 'view';
$item_id = $_GET['id'] ?? null;
$message = '';
$error = '';

// Handle form submissions for add/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $name = trim($_POST['name']);
    $price = trim($_POST['price']);
    $description = trim($_POST['description']);
    $is_available = isset($_POST['is_available_today']) ? 1 : 0;

    if (empty($name) || !is_numeric($price)) {
        $error = "Name is required and Price must be a number.";
    } else {
        if ($id) { // Update existing item
            $sql = "UPDATE menu_items SET name = ?, price = ?, description = ?, is_available_today = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$name, $price, $description, $is_available, $id]);
            $message = "Menu item updated successfully!";
        } else { // Add new item
            $sql = "INSERT INTO menu_items (name, price, description, is_available_today) VALUES (?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$name, $price, $description, $is_available]);
            $message = "New menu item added successfully!";
        }
        $action = 'view'; // Go back to view after action
    }
}

// Handle delete action
if ($action === 'delete' && $item_id) {
    $sql = "DELETE FROM menu_items WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$item_id]);
    $message = "Menu item deleted successfully!";
    $action = 'view';
}

// Handle toggle availability
if ($action === 'toggle' && $item_id) {
    $sql = "UPDATE menu_items SET is_available_today = !is_available_today WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$item_id]);
    $message = "Availability toggled successfully!";
    $action = 'view';
}

// Fetch data for view/edit
$menu_items = [];
$item_to_edit = null;
if ($action === 'view') {
    $menu_items = $pdo->query("SELECT * FROM menu_items ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} elseif (($action === 'edit' || $action === 'add') && $item_id) {
    $stmt = $pdo->prepare("SELECT * FROM menu_items WHERE id = ?");
    $stmt->execute([$item_id]);
    $item_to_edit = $stmt->fetch(PDO::FETCH_ASSOC);
}


$page_title = "Menu Management";
require_once '../includes/header.php';
?>
<div class="d-flex">
    <?php require_once '../includes/admin_sidebar.php'; ?>
    <div class="container-fluid p-4">
        <h1 class="mb-4">Menu Management</h1>

        <?php if ($message): ?><div class="alert alert-success"><?php echo $message; ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>

        <?php if ($action === 'add' || $action === 'edit'): ?>
            <h3><?php echo $action === 'add' ? 'Add New Menu Item' : 'Edit Menu Item'; ?></h3>
            <form action="menu_management.php" method="post" class="card p-3">
                <input type="hidden" name="id" value="<?php echo $item_to_edit['id'] ?? ''; ?>">
                <div class="mb-3">
                    <label for="name" class="form-label">Item Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($item_to_edit['name'] ?? ''); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Price (<?php echo CURRENCY_SYMBOL; ?>)</label>
                    <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?php echo htmlspecialchars($item_to_edit['price'] ?? ''); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description (Optional)</label>
                    <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($item_to_edit['description'] ?? ''); ?></textarea>
                </div>
                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" id="is_available_today" name="is_available_today" <?php echo (isset($item_to_edit['is_available_today']) && $item_to_edit['is_available_today']) || $action === 'add' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="is_available_today">Available Today</label>
                </div>
                <button type="submit" class="btn btn-primary">Save Item</button>
                <a href="menu_management.php" class="btn btn-secondary mt-2">Cancel</a>
            </form>
        <?php else: ?>
            <a href="?action=add" class="btn btn-primary mb-3"><i class="bi bi-plus-circle"></i> Add New Item</a>
            <div class="card">
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th class="text-end">Price</th>
                                <th class="text-center">Available Today</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($menu_items as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                                    <td class="text-end"><?php echo CURRENCY_SYMBOL; ?> <?php echo number_format($item['price'], 2); ?></td>
                                    <td class="text-center">
                                        <?php if ($item['is_available_today']): ?>
                                            <span class="badge bg-success">Yes</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">No</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <a href="?action=toggle&id=<?php echo $item['id']; ?>" class="btn btn-sm btn-outline-secondary" title="Toggle Availability"><i class="bi bi-arrow-repeat"></i></a>
                                        <a href="?action=edit&id=<?php echo $item['id']; ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                        <a href="?action=delete&id=<?php echo $item['id']; ?>" class="btn btn-sm btn-outline-danger delete-btn" title="Delete"><i class="bi bi-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>