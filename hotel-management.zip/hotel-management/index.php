<?php
require_once 'config.php';
require_once 'includes/auth_check.php';
$page_title = "Today's Menu";
require_once 'includes/header.php';

// Fetch today's available menu items
$sql = "SELECT id, name, price, description FROM menu_items WHERE is_available_today = 1 ORDER BY name ASC";
$menu_items = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1>Today's Menu</h1>
        <span class="text-muted"><?php echo date("l, F j, Y"); ?></span>
    </div>

    <?php if (isset($_GET['order']) && $_GET['order'] == 'success'): ?>
        <div class="alert alert-success">Your order has been placed successfully!</div>
    <?php endif; ?>

    <?php if (count($menu_items) > 0): ?>
        <form action="order_summary.php" method="post">
            <div class="list-group">
                <?php foreach ($menu_items as $item): ?>
                    <div class="list-group-item">
                        <div class="row align-items-center">
                            <div class="col-md-5">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="items[<?php echo $item['id']; ?>][id]" value="<?php echo $item['id']; ?>" id="item_<?php echo $item['id']; ?>">
                                    <label class="form-check-label fw-bold" for="item_<?php echo $item['id']; ?>">
                                        <?php echo htmlspecialchars($item['name']); ?>
                                    </label>
                                    <?php if (!empty($item['description'])): ?>
                                        <small class="d-block text-muted"><?php echo htmlspecialchars($item['description']); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <span class="badge bg-secondary p-2"><?php echo CURRENCY_SYMBOL; ?> <?php echo number_format($item['price'], 2); ?></span>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group">
                                    <span class="input-group-text">Qty</span>
                                    <input type="number" name="items[<?php echo $item['id']; ?>][quantity]" class="form-control" value="1" min="1" max="10">
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="text-end mt-4">
                <button type="submit" class="btn btn-primary btn-lg">Next: Review Order</button>
            </div>
        </form>
    <?php else: ?>
        <div class="alert alert-info">The menu for today has not been set yet. Please check back later.</div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>