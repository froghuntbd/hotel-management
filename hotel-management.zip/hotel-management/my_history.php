<?php
require_once 'config.php';
require_once 'includes/auth_check.php';

$page_title = "My Purchase History";
require_once 'includes/header.php';

$user_id = $_SESSION['user_id'];
$filter_type = $_GET['filter'] ?? 'monthly';
$where_clause = "";

switch ($filter_type) {
    case 'daily':
        $where_clause = "AND o.order_date = CURDATE()";
        break;
    case 'weekly':
        $where_clause = "AND o.order_date >= CURDATE() - INTERVAL 7 DAY";
        break;
    case 'monthly':
    default:
        $where_clause = "AND o.order_date >= CURDATE() - INTERVAL 30 DAY";
        break;
}

$sql = "SELECT o.id, o.order_date, o.total_amount, o.status 
        FROM orders o 
        WHERE o.user_id = ? $where_clause
        ORDER BY o.order_date DESC, o.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="container mt-4 printable-area">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1>My Purchase History</h1>
        <div>
            <button class="btn btn-secondary d-print-none" onclick="window.print()">
                <i class="bi bi-printer"></i> Print
            </button>
        </div>
    </div>

    <div class="d-flex justify-content-center my-3 d-print-none">
        <div class="btn-group" role="group">
            <a href="my_history.php?filter=daily" class="btn <?php echo $filter_type == 'daily' ? 'btn-primary' : 'btn-outline-primary'; ?>">Daily</a>
            <a href="my_history.php?filter=weekly" class="btn <?php echo $filter_type == 'weekly' ? 'btn-primary' : 'btn-outline-primary'; ?>">Weekly</a>
            <a href="my_history.php?filter=monthly" class="btn <?php echo $filter_type == 'monthly' ? 'btn-primary' : 'btn-outline-primary'; ?>">Monthly</a>
        </div>
    </div>
    
    <div class="card">
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Date</th>
                        <th>Items</th>
                        <th class="text-end">Total Amount</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($orders) > 0): ?>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td>#<?php echo $order['id']; ?></td>
                                <td><?php echo date("d M, Y", strtotime($order['order_date'])); ?></td>
                                <td>
                                    <ul class="list-unstyled mb-0">
                                    <?php 
                                    $item_sql = "SELECT mi.name, oi.quantity FROM order_items oi JOIN menu_items mi ON oi.menu_item_id = mi.id WHERE oi.order_id = ?";
                                    $item_stmt = $pdo->prepare($item_sql);
                                    $item_stmt->execute([$order['id']]);
                                    $items = $item_stmt->fetchAll(PDO::FETCH_ASSOC);
                                    foreach ($items as $item) {
                                        echo '<li>' . htmlspecialchars($item['name']) . ' (x' . $item['quantity'] . ')</li>';
                                    }
                                    ?>
                                    </ul>
                                </td>
                                <td class="text-end"><?php echo CURRENCY_SYMBOL; ?> <?php echo number_format($order['total_amount'], 2); ?></td>
                                <td><span class="badge bg-info text-dark"><?php echo ucfirst(str_replace('_', ' ', $order['status'])); ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center">No purchase history found for this period.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>